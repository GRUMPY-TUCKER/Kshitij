from firebase_admin import messaging, credentials, initialize_app

FIREBASE_CONFIG_PATH = r"your_private_key"  
cred = credentials.Certificate(FIREBASE_CONFIG_PATH)
firebase_app = initialize_app(cred)  

def send_dummy_notification(token):
    try:
        message = messaging.Message(
            notification=messaging.Notification(
                title="Test Notification",
                body="This is a dummy notification sent via Python!",
            ),
            token=token,
        )
        response = messaging.send(message)
        print(f"FCM Notification sent successfully: {response}")
    except Exception as e:
        print(f"Error sending FCM notification: {e}")

if _name_ == "_main_": 
    device_token = "token"

    print("Sending a dummy notification...")
    send_dummy_notification(device_token)