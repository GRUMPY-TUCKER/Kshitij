package com.example.kshitijsih

data class BeachData(
    val lat: Double,
    val lng: Double,
    val start: String,
    val end: String,
    val params: String) {
}